export interface Book {
  id: number;
  title: string;
  author: string;
  publishedAt: Date | string;
  description?: string | null;
  summary?: string | null;
  category?: string | null;
}

export interface MenuItem {
  id: number;
  name: string;
  price: number | string;
  image_url: string;
}

export interface Order {
  id: number;
  quantity: number;
  notes: string;
  created_at: string;
  menu_name: string;
}