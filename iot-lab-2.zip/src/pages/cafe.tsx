import { useState } from 'react';
import useSWR from 'swr';
import { notifications } from '@mantine/notifications';
import { Card, Image, Text, Button, Group, Badge, Modal, NumberInput, Textarea } from '@mantine/core';
import Layout from '../components/layout';
import Loading from '../components/loading';
import { MenuItem } from '../lib/models';
import { useDisclosure } from '@mantine/hooks';
import axios from 'axios';

export default function CafePage() {
    const { data: response, error } = useSWR<{ data: MenuItem[] }>('/cafe/menus');
    const [opened, { open, close }] = useDisclosure(false);
    const [selectedMenu, setSelectedMenu] = useState<MenuItem | null>(null);
    const [quantity, setQuantity] = useState(1);
    const [notes, setNotes] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);

    const handleOrderClick = (menu: MenuItem) => {
        setSelectedMenu(menu);
        setQuantity(1);
        setNotes('');
        open();
    };

    const handleSubmitOrder = async () => {
        if (!selectedMenu) return;
        setIsProcessing(true);
        try {
            await axios.post('/cafe/orders', {
                menu_id: selectedMenu.id,
                quantity,
                notes,
            });
            notifications.show({
                title: 'สั่งเครื่องดื่มสำเร็จ',
                message: `คุณได้สั่ง ${selectedMenu.name} จำนวน ${quantity} แก้ว`,
                color: 'teal',
            });
            close();
        } catch (err) {
            notifications.show({
                title: 'เกิดข้อผิดพลาด',
                message: 'ไม่สามารถสั่งเครื่องดื่มได้ กรุณาลองใหม่',
                color: 'red',
            });
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <Layout>
            <section className="container mx-auto py-8">
                <h1 className="text-3xl font-bold mb-4">เมนูเครื่องดื่ม</h1>
                {!response && !error && <Loading />}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {response?.data?.map((menu) => (
                        <Card shadow="sm" padding="lg" radius="md" withBorder key={menu.id}>
                            <Card.Section>
                                <Image src={menu.image_url} height={160} alt={menu.name} />
                            </Card.Section>
                            <Group justify="space-between" mt="md" mb="xs">
                                <Text fw={500}>{menu.name}</Text>
                                <Badge color="pink" variant="light">
                                    {Number(menu.price).toFixed(2)} ฿
                                </Badge>
                            </Group>
                            <Button color="blue" fullWidth mt="md" radius="md" onClick={() => handleOrderClick(menu)}>
                                สั่งเครื่องดื่ม
                            </Button>
                        </Card>
                    ))}
                </div>
            </section>

            <Modal opened={opened} onClose={close} title={`สั่ง ${selectedMenu?.name}`} centered>
                <div className="space-y-4">
                    <NumberInput
                        label="จำนวน"
                        value={quantity}
                        onChange={(val) => setQuantity(Number(val))}
                        min={1}
                        max={20}
                    />
                    <Textarea
                        label="หมายเหตุเพิ่มเติม"
                        placeholder="เช่น หวานน้อย, ไม่ใส่ฟองนม..."
                        value={notes}
                        onChange={(event) => setNotes(event.currentTarget.value)}
                    />
                    <Button fullWidth onClick={handleSubmitOrder} loading={isProcessing}>
                        ยืนยันการสั่งซื้อ
                    </Button>
                </div>
            </Modal>
        </Layout>
    );
}