import { Container } from "@mantine/core";
import Layout from "../components/layout";

export default function HomePage() {
  return (
    <Layout>
      <Container>
        <section className="text-center py-16">
          <h1 className="text-5xl font-bold mb-4">ยินดีต้อนรับสู่ร้านหนังสือของเรา</h1>
          <p className="text-lg text-neutral-500">
            ค้นหาหนังสือเล่มโปรดของคุณได้ที่นี่
          </p>
        </section>

        <section className="container mx-auto py-8 text-center bg-slate-50 rounded-lg">
          <h2 className="text-3xl font-bold mb-6">ผู้ดูแลระบบ</h2>
          <div className="max-w-sm mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-8">
              <div className="uppercase tracking-wide text-sm text-indigo-500 font-semibold">
                System Administrator
              </div>
              <p className="block mt-1 text-2xl leading-tight font-bold text-black">
                MR.PETCHPRAETHONG INUTHAI
              </p>
              <p className="mt-2 text-gray-500 text-lg">
                STUDENT ID: 66070139
              </p>
            </div>
          </div>
        </section>
      </Container>
    </Layout>
  );
}