import { useNavigate } from "react-router-dom";
import Layout from "../components/layout";
import { Button, Container, Divider, TextInput, Textarea } from "@mantine/core";
import { useForm } from "@mantine/form";
import { useState } from "react";
import axios from "axios";
import { notifications } from "@mantine/notifications";
import { DateTimePicker } from "@mantine/dates";

export default function BookCreatePage() {
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);

  const bookCreateForm = useForm({
    initialValues: {
      title: "",
      author: "",
      publishedAt: new Date(),
      description: "",
      summary: "",
      category: "",
    }
  });

  const handleSubmit = async (values: typeof bookCreateForm.values) => {
    try {
      setIsProcessing(true);
      const response = await axios.post(`/books`, values);
      notifications.show({
        title: "เพิ่มข้อมูลหนังสือสำเร็จ",
        message: "ข้อมูลหนังสือได้รับการเพิ่มเรียบร้อยแล้ว",
        color: "teal",
      });
      navigate(`/books/${response.data.book.id}`);
    } catch (error) {
      notifications.show({ title: "เกิดข้อผิดพลาด", message: "ไม่สามารถเพิ่มข้อมูลหนังสือได้", color: "red" });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Layout>
      <Container className="mt-8">
        <h1 className="text-xl">เพิ่มหนังสือในระบบ</h1>
        <form onSubmit={bookCreateForm.onSubmit(handleSubmit)} className="space-y-8 mt-4">
          <TextInput label="ชื่อหนังสือ" {...bookCreateForm.getInputProps("title")} required />
          <TextInput label="ชื่อผู้แต่ง" {...bookCreateForm.getInputProps("author")} required />
          <DateTimePicker label="วันที่พิมพ์" {...bookCreateForm.getInputProps("publishedAt")} required />
          <TextInput
            label="หมวดหมู่"
            placeholder="เช่น นิยาย, สารคดี..."
            {...bookCreateForm.getInputProps("category")}
          />
          <Textarea label="รายละเอียด" {...bookCreateForm.getInputProps("description")} autosize minRows={4} />
          <Textarea label="เรื่องย่อ" {...bookCreateForm.getInputProps("summary")} autosize minRows={2} />
          <Divider />
          <Button type="submit" loading={isProcessing}>บันทึกข้อมูล</Button>
        </form>
      </Container>
    </Layout>
  );
}