import useSWR from 'swr';
import Layout from '../components/layout';
import Loading from '../components/loading';
import { Order } from '../lib/models';
import { Table, ScrollArea } from '@mantine/core';
import dayjs from "dayjs";

export default function StaffOrdersPage() {
  const { data: response, error } = useSWR<{ data: Order[] }>('/cafe/orders');

  const rows = response?.data?.map((order) => (
    <Table.Tr key={order.id}>
      <Table.Td>{order.id}</Table.Td>
      <Table.Td>{order.menu_name}</Table.Td>
      <Table.Td>{order.quantity}</Table.Td>
      <Table.Td>{order.notes || '-'}</Table.Td>
      <Table.Td>{dayjs(order.created_at).format('DD/MM/YYYY HH:mm')}</Table.Td>
    </Table.Tr>
  ));

  return (
    <Layout>
      <section className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-4">รายการสั่งซื้อทั้งหมด</h1>
        {!response && !error && <Loading />}
        <ScrollArea>
          <Table miw={800} verticalSpacing="sm">
            <Table.Thead>
              <Table.Tr>
                <Table.Th>Order ID</Table.Th>
                <Table.Th>เมนู</Table.Th>
                <Table.Th>จำนวน</Table.Th>
                <Table.Th>หมายเหตุ</Table.Th>
                <Table.Th>เวลาที่สั่ง</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>{rows}</Table.Tbody>
          </Table>
        </ScrollArea>
      </section>
    </Layout>
  );
}