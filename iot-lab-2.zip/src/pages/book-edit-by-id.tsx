import { useParams, useNavigate } from "react-router-dom";
import useSWR from "swr";
import Layout from "../components/layout";
import { Book } from "../lib/models";
import Loading from "../components/loading";
import { notifications } from "@mantine/notifications";
import { useEffect, useState } from "react";
import { Button, Container, Divider, TextInput, Textarea } from "@mantine/core";
import { useForm } from "@mantine/form";
import { DateTimePicker } from "@mantine/dates";
import axios from "axios";

export default function BookEditById() {
  const { bookId } = useParams();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);

  const { data: book, error } = useSWR<Book>(`/books/${bookId}`);

  const bookEditForm = useForm({
    initialValues: {
      title: "",
      author: "",
      publishedAt: new Date(),
      description: "",
      summary: "",
      category: "",
    }
  });

  useEffect(() => {
    if (book) {
      bookEditForm.setValues({
        title: book.title,
        author: book.author,
        publishedAt: new Date(book.publishedAt),
        description: book.description || "",
        summary: book.summary || "",
        category: book.category || "",
      });
    }
  }, [book]);

  const handleSubmit = async (values: typeof bookEditForm.values) => {
    try {
      setIsProcessing(true);
      await axios.patch(`/books/${bookId}`, values);
      notifications.show({
        title: "แก้ไขข้อมูลสำเร็จ",
        message: "ข้อมูลหนังสือได้รับการอัปเดตเรียบร้อยแล้ว",
        color: "teal",
      });
      navigate(`/books/${bookId}`);
    } catch (err) {
      notifications.show({ title: "เกิดข้อผิดพลาด", message: "ไม่สามารถแก้ไขข้อมูลได้", color: "red" });
    } finally {
      setIsProcessing(false);
    }
  };

  if (!book && !error) return <Loading />;

  return (
    <Layout>
      <Container className="mt-8">
        <h1 className="text-xl">แก้ไขรายละเอียดหนังสือ</h1>
        <form onSubmit={bookEditForm.onSubmit(handleSubmit)} className="space-y-8 mt-4">
          <TextInput label="ชื่อหนังสือ" {...bookEditForm.getInputProps("title")} required />
          <TextInput label="ชื่อผู้แต่ง" {...bookEditForm.getInputProps("author")} required />
          <DateTimePicker label="วันที่พิมพ์" {...bookEditForm.getInputProps("publishedAt")} required />
          <TextInput
            label="หมวดหมู่"
            placeholder="เช่น นิยาย, สารคดี..."
            {...bookEditForm.getInputProps("category")}
          />
          <Textarea label="รายละเอียด" {...bookEditForm.getInputProps("description")} autosize minRows={4} />
          <Textarea label="เรื่องย่อ" {...bookEditForm.getInputProps("summary")} autosize minRows={2} />
          <Divider />
          <Button type="submit" loading={isProcessing}>บันทึกข้อมูล</Button>
        </form>
      </Container>
    </Layout>
  );
}