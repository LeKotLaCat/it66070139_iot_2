import { Alert, Badge, Button, Container, Divider, Text, Group } from "@mantine/core";
import Layout from "../components/layout";
import { Link, useParams, useNavigate } from "react-router-dom";
import { Book } from "../lib/models";
import useSWR, { useSWRConfig } from "swr";
import Loading from "../components/loading";
import { IconAlertTriangleFilled, IconEdit, IconTrash } from "@tabler/icons-react";
import dayjs from "dayjs";
import "dayjs/locale/th";
import buddhistEra from "dayjs/plugin/buddhistEra";
import bookCoverImage from "../assets/images/aj-panwit.jpg";
import { modals } from "@mantine/modals";
import axios from "axios";
import { notifications } from "@mantine/notifications";

dayjs.locale("th");
dayjs.extend(buddhistEra);

export default function BookByIdPage() {
  const { bookId } = useParams();
  const navigate = useNavigate();
  const { mutate } = useSWRConfig();

  const { data: book, error, isLoading } = useSWR<Book>(`/books/${bookId}`);

  const handleDelete = async () => {
    try {
      await axios.delete(`/books/${bookId}`);
      notifications.show({
        title: "ลบหนังสือสำเร็จ",
        message: "ข้อมูลหนังสือเล่มนี้ถูกลบออกจากระบบเรียบร้อยแล้ว",
        color: "red",
      });
      mutate('/books');
      navigate("/books");
    } catch (err) {
      notifications.show({
        title: "เกิดข้อผิดพลาด",
        message: "ไม่สามารถลบข้อมูลหนังสือได้",
        color: "red",
      });
    }
  };

  const openDeleteModal = () =>
    modals.openConfirmModal({
      title: 'คุณแน่ใจหรือไม่?',
      centered: true,
      children: (
        <Text size="sm">
          การลบหนังสือเล่มนี้จะเป็นการลบข้อมูลอย่างถาวรและไม่สามารถกู้คืนได้
        </Text>
      ),
      labels: { confirm: 'ยืนยันการลบ', cancel: "ยกเลิก" },
      confirmProps: { color: 'red' },
      onConfirm: () => handleDelete(),
    });

  return (
    <Layout>
      <Container className="mt-4">
        {isLoading && !error && <Loading />}
        {error && (
          <Alert color="red" title="เกิดข้อผิดพลาด" icon={<IconAlertTriangleFilled />}>
            {error.message}
          </Alert>
        )}
        {!!book && (
          <>
            <h1>{book.title}</h1>
            <p className="italic text-neutral-500 mb-2">โดย {book.author}</p>
            <p className="text-sm text-neutral-600 mb-4">
              ตีพิมพ์เมื่อ: {dayjs(book.publishedAt).format("DD MMMM BBBB")}
            </p>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <img src={bookCoverImage} alt={book.title} className="w-full object-cover aspect-[3/4]" />
              <div className="col-span-2 space-y-4">
                <div>
                  <h3>รายละเอียดหนังสือ</h3>
                  <p className="indent-4 text-sm text-neutral-700">{book.description || "ไม่มีรายละเอียด"}</p>
                </div>
                <div>
                  <h3>เรื่องย่อ</h3>
                  <p className="indent-4 text-sm text-neutral-700">{book.summary || "ไม่มีเรื่องย่อ"}</p>
                </div>
                <div>
                  <h3>หมวดหมู่</h3>
                  {book.category ? (
                    <Badge color="teal">{book.category}</Badge>
                  ) : (
                    <Text size="sm" c="dimmed">ไม่มีหมวดหมู่</Text>
                  )}
                </div>
              </div>
            </div>
            <Divider className="mt-6" />

            <Group mt="md">
              <Button
                color="blue"
                size="xs"
                component={Link}
                to={`/books/${book.id}/edit`}
                leftSection={<IconEdit />}
              >
                แก้ไขข้อมูลหนังสือ
              </Button>
              <Button
                color="red"
                size="xs"
                onClick={openDeleteModal}
                leftSection={<IconTrash />}
              >
                ลบหนังสือ
              </Button>
            </Group>
            
          </>
        )}
      </Container>
    </Layout>
  );
}