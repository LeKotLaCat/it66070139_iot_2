import { useState } from 'react';
import Layout from "../components/layout";
import useSWR from "swr";
import { Book } from "../lib/models";
import Loading from "../components/loading";
import { Alert, Button, TextInput } from "@mantine/core";
import { IconAlertTriangleFilled, IconPlus, IconSearch } from "@tabler/icons-react";
import { Link } from "react-router-dom";
import bookCoverImage from "../assets/images/aj-panwit.jpg";

export default function BooksPage() {
  const [searchCategory, setSearchCategory] = useState('');

  const swrKey = searchCategory ? `/books?category=${encodeURIComponent(searchCategory)}` : '/books';
  const { data: booksResponse, error } = useSWR<{ data: Book[] }>(swrKey);

  return (
    <Layout>
      <section className="container mx-auto py-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">รายการหนังสือ</h1>
          <Button component={Link} leftSection={<IconPlus />} to="/books/create" size="sm">
            เพิ่มหนังสือ
          </Button>
        </div>
        
        <div className="mt-4">
          <TextInput
            label="กรองตามหมวดหมู่"
            placeholder="เช่น นิยาย, สารคดี..."
            leftSection={<IconSearch size={16} />}
            value={searchCategory}
            onChange={(event) => setSearchCategory(event.currentTarget.value)}
          />
        </div>

        {!booksResponse && !error && <div className="mt-8"><Loading /></div>}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
          {booksResponse?.data?.map((book) => (
            <div className="border border-solid border-neutral-200" key={book.id}>
              <img src={bookCoverImage} alt={book.title} className="w-full object-cover aspect-[3/4]" />
              <div className="p-4">
                <h2 className="text-lg font-semibold line-clamp-2">{book.title}</h2>
                <p className="text-xs text-neutral-500">โดย {book.author}</p>
              </div>
              <div className="flex justify-between items-center px-4 pb-2">
                <span className="text-xs bg-gray-200 text-gray-700 px-2 py-1 rounded-full">{book.category || 'ไม่มีหมวดหมู่'}</span>
                <Button component={Link} to={`/books/${book.id}`} size="xs" variant="default">
                  ดูรายละเอียด
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </Layout>
  );
}