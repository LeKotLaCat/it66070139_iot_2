import { Hono } from 'hono';
import booksRouter from './books';
import cafeRouter from './cafe'; // 1. Import cafeRouter

const apiRouter = new Hono();

apiRouter.route('/books', booksRouter);
apiRouter.route('/cafe', cafeRouter); // 2. เพิ่ม cafeRouter

export default apiRouter;