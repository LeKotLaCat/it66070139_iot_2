import { Hono } from 'hono';
import getDbPool from '../db/database';
import type { RowDataPacket } from 'mysql2';

const cafeRouter = new Hono();

// GET /api/v1/cafe/menus -> ดึงรายการเมนูทั้งหมด
cafeRouter.get('/menus', async (c) => {
  const pool = getDbPool();
  try {
    const [rows] = await pool.query('SELECT * FROM menus ORDER BY id ASC');
    return c.json({ data: rows });
  } catch (error) {
    console.error('Failed to fetch menus:', error);
    return c.json({ error: 'Failed to fetch menus' }, 500);
  }
});

// GET /api/v1/cafe/orders -> ดึงรายการสั่งซื้อทั้งหมด (สำหรับ Staff)
cafeRouter.get('/orders', async (c) => {
  const pool = getDbPool();
  try {
    const query = `
      SELECT o.id, o.quantity, o.notes, o.created_at, m.name AS menu_name
      FROM orders AS o
      JOIN menus AS m ON o.menu_id = m.id
      ORDER BY o.created_at DESC
    `;
    const [rows] = await pool.query(query);
    return c.json({ data: rows });
  } catch (error) {
    console.error('Failed to fetch orders:', error);
    return c.json({ error: 'Failed to fetch orders' }, 500);
  }
});

// POST /api/v1/cafe/orders -> สร้างออเดอร์ใหม่
cafeRouter.post('/orders', async (c) => {
  const pool = getDbPool();
  try {
    const { menu_id, quantity, notes } = await c.req.json();

    if (!menu_id || !quantity) {
      return c.json({ error: 'Missing menu_id or quantity' }, 400);
    }

    const [result] = await pool.query(
      'INSERT INTO orders (menu_id, quantity, notes) VALUES (?, ?, ?)',
      [menu_id, quantity, notes]
    ) as any;
    
    return c.json({ message: 'Order created successfully', orderId: result.insertId }, 201);

  } catch (error) {
    console.error('Failed to create order:', error);
    return c.json({ error: 'Failed to create order' }, 500);
  }
});

export default cafeRouter;