import { Box, Button } from "@mantine/core";
import { Link } from "react-router-dom";
import { IconCoffee, IconClipboardList } from '@tabler/icons-react';
import websiteLogo from "../assets/website-logo.png";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <>
      <Box>
        <header className="h-16 px-8 border-b border-solid border-neutral-200 bg-white flex items-center justify-between">
          
          <div className="flex items-center gap-8">
            <Link to="/">
              <img src={websiteLogo} alt="Website Logo" className="h-10" />
            </Link>
            
            <nav className="flex items-center gap-4">
              <Button component={Link} to="/books" variant="subtle" color="gray" size="md">
                หนังสือ
              </Button>
              <Button component={Link} to="/cafe" variant="subtle" color="gray" size="md" leftSection={<IconCoffee size={18} />}>
                สั่งเครื่องดื่ม
              </Button>
            </nav>
          </div>

          <div className="flex items-center">
            <Button
              component={Link}
              to="/staff/orders"
              variant="light"
              leftSection={<IconClipboardList size={16} />}
            >
              สำหรับ Staff
            </Button>
          </div>
          
        </header>
      </Box>

      <main className="p-8">
        {children}
      </main>
    </>
  );
}