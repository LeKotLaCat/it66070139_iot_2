// src/db/schema.ts
import { mysqlTable, int, varchar, datetime } from 'drizzle-orm/mysql-core';

export const books = mysqlTable('books', {
   id: int('id').autoincrement().primaryKey(),
  title: varchar('title', { length: 255 }).notNull(),
  author: varchar('author', { length: 255 }).notNull(),
  publishedAt: datetime('published_at').notNull(),
});