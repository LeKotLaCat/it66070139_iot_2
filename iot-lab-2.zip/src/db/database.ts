import 'dotenv/config';
import mysql from 'mysql2/promise';
import type { Pool } from 'mysql2/promise';

let poolInstance: Pool | null = null;

const getDbPool = (): Pool => {
  if (poolInstance) {
    return poolInstance;
  }

  const { DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, DB_PORT } = process.env;

  if (!DB_HOST || !DB_USER || !DB_PASSWORD || !DB_NAME || !DB_PORT) {
    const missing = [
      !DB_HOST && 'DB_HOST',
      !DB_USER && 'DB_USER',
      !DB_PASSWORD && 'DB_PASSWORD',
      !DB_NAME && 'DB_NAME',
      !DB_PORT && 'DB_PORT',
    ].filter(Boolean).join(', ');
    throw new Error(`Missing database environment variables: ${missing}`);
  }

  const dbConfig = {
    host: DB_HOST,
    user: DB_USER,
    password: DB_PASSWORD,
    database: DB_NAME,
    port: parseInt(DB_PORT, 10),
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  };

  console.log('Creating a NEW database pool with config:', dbConfig);
  poolInstance = mysql.createPool(dbConfig);
  
  poolInstance.on('error', (err) => {
    console.error('Database pool error:', err);
  });

  return poolInstance;
};

export default getDbPool;