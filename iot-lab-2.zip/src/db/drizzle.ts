

import 'dotenv/config'
import { drizzle } from 'drizzle-orm/mysql2'
import mysql from 'mysql2/promise'
import * as schema from './schema';

// อ่านค่าจาก Environment Variables
const { DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE, DB_PORT } = process.env;

// ตรวจสอบให้แน่ใจว่าตัวแปรที่จำเป็นถูกตั้งค่าครบถ้วน
if (!DB_HOST || !DB_USER || !DB_PASSWORD || !DB_DATABASE || !DB_PORT) {
  throw new Error('Database environment variables are not set in .env file');
}

// สร้าง Connection Pool โดยระบุค่าแต่ละตัว
const poolConnection = mysql.createPool({
  host: DB_HOST,
  user: DB_USER,
  password: DB_PASSWORD,
  database: DB_DATABASE,
  port: parseInt(DB_PORT, 10), // แปลง Port ให้เป็นตัวเลข
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// สร้าง Drizzle instance โดยใช้ pool และระบุ schema
// การใส่ schema เข้าไปตรงๆ จะทำให้ drizzle.query.books.findFirst(...) ใช้งานได้
const drizzleClient = drizzle(poolConnection, { schema, mode: 'default' });

export default drizzleClient;