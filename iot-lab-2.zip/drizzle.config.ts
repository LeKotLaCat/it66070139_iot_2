// drizzle.config.ts (ฉบับแก้ไขครั้งสุดท้ายจริงๆ)

import type { Config } from 'drizzle-kit';
import 'dotenv/config';

export default {
  schema: './src/db/schema.ts',
  out: './drizzle',
  dialect: 'mysql', // <--- ตัวนี้ถูกต้องและจำเป็น
  // driver: 'mysql2', // <--- ลบบรรทัดนี้ทิ้งไปเลย
  dbCredentials: {
    host: process.env.DB_HOST!,
    user: process.env.DB_USER!,
    password: process.env.DB_PASSWORD!,
    database: process.env.DB_DATABASE!,
    port: parseInt(process.env.DB_PORT!, 10),
  },
} satisfies Config;