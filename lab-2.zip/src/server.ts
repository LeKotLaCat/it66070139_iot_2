import 'dotenv/config';
import { serve } from '@hono/node-server';
import { Hono } from 'hono';
import { cors } from 'hono/cors';
import apiRouter from './routes/api';

const app = new Hono();

app.use('/api/*', cors({
  origin: 'http://localhost:5173',
}));

app.route('/api/v1', apiRouter);

const port = parseInt(process.env.PORT || '3000', 10);

serve({
  fetch: app.fetch,
  port
}, (info) => {
  console.log(`✅ Backend server is running on ${info.address}:${info.port}`);
});