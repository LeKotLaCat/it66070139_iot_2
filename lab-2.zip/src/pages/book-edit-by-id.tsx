import { useParams, useNavigate } from "react-router-dom";
import useSWR from "swr";
import Layout from "../components/layout";
import { Book } from "../lib/models";
import Loading from "../components/loading";
import { notifications } from "@mantine/notifications";
import { useEffect, useState } from "react";
import { Button, Container, Divider, TextInput, Alert, Textarea } from "@mantine/core";
import { isNotEmpty, useForm } from "@mantine/form";
import { DateTimePicker } from "@mantine/dates";
import axios, { AxiosError } from "axios";
import { IconAlertTriangleFilled } from "@tabler/icons-react";

export default function BookEditById() {
  const { bookId } = useParams();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);

  const { data: book, error } = useSWR<Book>(`/books/${bookId}`);

  const bookEditForm = useForm({
    initialValues: {
      title: "",
      author: "",
      publishedAt: new Date(),
      description: "",
      summary: "",
    },
    validate: {
      title: isNotEmpty("กรุณาระบุชื่อหนังสือ"),
      author: isNotEmpty("กรุณาระบุชื่อผู้แต่ง"),
      publishedAt: isNotEmpty("กรุณาระบุวันที่พิมพ์หนังสือ"),
    },
  });

  useEffect(() => {
    if (book) {
      bookEditForm.setValues({
        title: book.title,
        author: book.author,
        publishedAt: new Date(book.publishedAt),
        description: book.description || "",
        summary: book.summary || "",
      });
    }
  }, [book]);

  const handleSubmit = async (values: typeof bookEditForm.values) => {
    try {
      setIsProcessing(true);
      await axios.patch(`/books/${bookId}`, values);
      notifications.show({
        title: "แก้ไขข้อมูลสำเร็จ",
        message: "ข้อมูลหนังสือได้รับการอัปเดตเรียบร้อยแล้ว",
        color: "teal",
      });
      navigate(`/books/${bookId}`);
    } catch (err) {
      if (err instanceof AxiosError) {
        if (err.response?.status === 404) {
          notifications.show({
            title: "ไม่พบข้อมูลหนังสือ",
            message: "ไม่พบข้อมูลหนังสือที่ต้องการแก้ไข",
            color: "red",
          });
        } else {
          notifications.show({
            title: "เกิดข้อผิดพลาดบางอย่าง",
            message: "กรุณาลองใหม่อีกครั้ง",
            color: "red",
          });
        }
      } else {
        notifications.show({
          title: "เกิดข้อผิดพลาดบางอย่าง",
          message: "กรุณาลองใหม่อีกครั้ง หรือดูที่ Console สำหรับข้อมูลเพิ่มเติม",
          color: "red",
        });
      }
    } finally {
      setIsProcessing(false);
    }
  };

  if (!book && !error) {
    return <Loading />;
  }

  if (error || !book) {
    return (
      <Layout>
        <Container className="mt-8">
          <Alert color="red" title="เกิดข้อผิดพลาด" icon={<IconAlertTriangleFilled />}>
            ไม่สามารถโหลดข้อมูลหนังสือได้ หรือไม่พบข้อมูลที่ต้องการ
          </Alert>
        </Container>
      </Layout>
    );
  }

  return (
    <Layout>
      <Container className="mt-8">
        <h1 className="text-xl">แก้ไขรายละเอียดหนังสือ</h1>
        <form onSubmit={bookEditForm.onSubmit(handleSubmit)} className="space-y-8 mt-4">
          <TextInput
            label="ชื่อหนังสือ"
            placeholder="ชื่อหนังสือ"
            {...bookEditForm.getInputProps("title")}
          />
          <TextInput
            label="ชื่อผู้แต่ง"
            placeholder="ชื่อผู้แต่ง"
            {...bookEditForm.getInputProps("author")}
          />
          <DateTimePicker
            valueFormat="DD MMMM YYYY, HH:mm"
            label="วันที่พิมพ์"
            placeholder="วันที่พิมพ์"
            {...bookEditForm.getInputProps("publishedAt")}
          />
          <Textarea
            label="รายละเอียด"
            placeholder="รายละเอียดหนังสือ..."
            {...bookEditForm.getInputProps("description")}
            autosize
            minRows={4}
          />
          <Textarea
            label="เรื่องย่อ"
            placeholder="เรื่องย่อ..."
            {...bookEditForm.getInputProps("summary")}
            autosize
            minRows={2}
          />
          <Divider />
          <Button type="submit" loading={isProcessing}>
            บันทึกข้อมูล
          </Button>
        </form>
      </Container>
    </Layout>
  );
}