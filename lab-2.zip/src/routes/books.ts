import { Hono } from 'hono';
import getDbPool from '../db/database';
import type { RowDataPacket } from 'mysql2';

const booksRouter = new Hono();

booksRouter.get('/', async (c) => {
  const pool = getDbPool();
  try {
    const [rows] = await pool.query('SELECT id, title, author, publishedAt FROM books ORDER BY id DESC');
    return c.json({ data: rows });
  } catch (error) {
    console.error('Failed to fetch books:', error);
    return c.json({ error: 'Failed to fetch books' }, 500);
  }
});

booksRouter.get('/:id', async (c) => {
  const pool = getDbPool();
  try {
    const id = c.req.param('id');
    const [rows] = await pool.query<RowDataPacket[]>('SELECT * FROM books WHERE id = ?', [id]);
    
    if (rows.length > 0) {
      return c.json(rows[0]);
    } else {
      return c.json({ error: 'Book not found' }, 404);
    }
  } catch (error) {
    console.error(`Failed to fetch book with id ${c.req.param('id')}:`, error);
    return c.json({ error: 'Failed to fetch book' }, 500);
  }
});

booksRouter.post('/', async (c) => {
  const pool = getDbPool();
  try {
    const { title, author, publishedAt, description, summary } = await c.req.json();

    if (!title || !author || !publishedAt) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    const [result] = await pool.query(
      'INSERT INTO books (title, author, publishedAt, description, summary) VALUES (?, ?, ?, ?, ?)',
      [title, author, new Date(publishedAt), description, summary]
    ) as any;
    
    if (result.insertId) {
      const [rows] = await pool.query<RowDataPacket[]>('SELECT * FROM books WHERE id = ?', [result.insertId]);
      if (rows.length > 0) {
        return c.json({ message: 'Book created successfully', book: rows[0] }, 201);
      }
    }
    
    throw new Error('Failed to retrieve the newly created book.');

  } catch (error) {
    console.error('Failed to create book:', error);
    return c.json({ error: 'Failed to create book' }, 500);
  }
});

booksRouter.patch('/:id', async (c) => {
  const pool = getDbPool();
  try {
    const id = c.req.param('id');
    const { title, author, publishedAt, description, summary } = await c.req.json();

    if (!title || !author || !publishedAt) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    const [result] = await pool.query(
      'UPDATE books SET title = ?, author = ?, publishedAt = ?, description = ?, summary = ? WHERE id = ?',
      [title, author, new Date(publishedAt), description, summary, id]
    ) as any;

    if (result.affectedRows === 0) {
      return c.json({ error: 'Book not found or no changes made' }, 404);
    }

    const [rows] = await pool.query<RowDataPacket[]>('SELECT * FROM books WHERE id = ?', [id]);

    if (rows.length > 0) {
      return c.json({ message: 'Book updated successfully', book: rows[0] });
    } else {
      return c.json({ error: 'Book not found after update' }, 404);
    }

  } catch (error) { // <-- เพิ่ม { ตรงนี้
    console.error(`Failed to update book with id ${c.req.param('id')}:`, error);
    return c.json({ error: 'Failed to update book' }, 500);
  }
});

booksRouter.delete('/:id', async (c) => {
  const pool = getDbPool();
  try {
    const id = c.req.param('id');
    const [result] = await pool.query(
      'DELETE FROM books WHERE id = ?',
      [id]
    ) as any;

    if (result.affectedRows === 0) {
      return c.json({ error: 'Book not found' }, 404);
    }

    return c.json({ message: 'Book deleted successfully' });
  } catch (error) {
    console.error(`Failed to delete book with id ${c.req.param('id')}:`, error);
    return c.json({ error: 'Failed to delete book' }, 500);
  }
});

export default booksRouter;