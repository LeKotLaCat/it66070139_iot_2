import { Hono } from 'hono';
import booksRouter from './books';

const apiRouter = new Hono();

apiRouter.route('/books', booksRouter);

export default apiRouter;