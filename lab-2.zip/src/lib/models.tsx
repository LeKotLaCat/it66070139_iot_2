export interface Book {
  id: number;
  title: string;
  author: string;
  publishedAt: Date | string;
  description?: string | null;
  summary?: string | null;
}