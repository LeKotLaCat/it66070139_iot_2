// test-db.js (ES Module Version)
import 'dotenv/config'; // ใช้ import แทน require
import mysql from 'mysql2/promise'; // ใช้ import แทน require

async function testConnection() {
  console.log('--- Database Connection Test ---');
  
  // ดึงค่าจาก process.env เหมือนเดิม
  const config = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
    port: parseInt(process.env.DB_PORT, 10),
  };

  console.log('Connecting with config:', config);

  let pool; // ประกาศ pool ข้างนอก try
  try {
    console.log('Attempting to create and get connection from pool...');
    pool = mysql.createPool(config);
    const connection = await pool.getConnection();
    console.log('✅ Connection successful! Connected to database.');

    console.log('Attempting to run a simple query...');
    const [rows] = await connection.query('SELECT 1 + 1 AS solution');
    console.log('✅ Query successful! The solution is:', rows[0].solution);

    connection.release();
    
  } catch (error) {
    console.error('❌ CONNECTION FAILED:', error.code, error.message);
  } finally {
    // ปิด pool ไม่ว่าจะสำเร็จหรือล้มเหลว
    if (pool) {
      await pool.end();
      console.log('Connection pool closed.');
    }
    console.log('--- Test Finished ---');
  }
}

testConnection();