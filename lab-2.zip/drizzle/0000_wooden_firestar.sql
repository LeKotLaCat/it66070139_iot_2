CREATE TABLE `books` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`author` varchar(255) NOT NULL,
	`published_at` datetime NOT NULL,
	CONSTRAINT `books_id` PRIMARY KEY(`id`)
);
